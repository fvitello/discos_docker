package org.exolab.castor.jdo.oql;

/**
 * Exception thrown to indicate that a feature is not supported by a particular database.
 *
 * @author <a href="mailto:werner DOT guttmann AT gmx DOT net">Werner Guttmann</a>
 * @version $Revision: 1.2 $ $Date: 2004/10/05 20:24:30 $
 */
public class SyntaxNotSupportedException extends OQLSyntaxException {
	/**
	 * @param message A description of the error encountered.
	 */
	public SyntaxNotSupportedException(String message) {
		super(message);
	}

	/**
	 * @param message A description of the error encountered.
	 * @param exception The root cause of this exception.
	 */
	public SyntaxNotSupportedException(String message, Throwable exception) {
		super(message, exception);
	}
}
